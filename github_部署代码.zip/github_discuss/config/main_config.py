USE_PROXY = False

# 定义常量
write_to_redis_day = 10  # 加载信源天数
priority_min = 0  # 信源优先级区间 低
priority_max = 5  # 信源优先级区间 高
urgent = False  # 是否只加载最高优先级信源
is_crawled = None  # 是否采集已结束的任务 (1:只获取已结束 / 0:只获取未结束 / None:获取所有任务)
read_mysql_limit = 100  # 每次读取批次数量 (数量 / None:获取所有任务)
REDIS_POOL_SIZE = 10  # 控制Redis连接池中维护的最大连接数
POLL_INTERVAL = 1  # 控制从MySQL查询新任务的频率
RETRY_INTERVAL = 5  # 发生错误（如连接失败）后的等待时间
ORDERBY_FILTER = "last_crawl_time"  # 排序字段
READ_REDIS_BATCH_SIZE = 100  # 读取Redis每批的数量
RESET_SLEEP_TIME = 600  # 重置offset等待时间

# --- [ Redis配置 ] ---
# REDIS_SERVER = "8.141.83.190" # 公网境内
# REDIS_SERVER = "8.222.245.96" # 公网境外
# REDIS_SERVER = "172.17.231.195"  # 专网境外
# REDIS_SERVER = "172.16.246.135" # 专网境内
REDIS_SERVER = "10.0.0.160"  # 测试
REDIS_PORT = 26379
REDIS_PWD = "Zx_redis0722"
REDIS_QUEUE = "topic_github_priority"
REDIS_QUEUE_UPDATE = "topic_github_priority_update"
REDIS_QUEUE_BE = "topic_github_priority_be"

# ---【MySQL配置】---
Mysql_database = "gdata"
Mysql_user = "root"
Mysql_pwd = "Zx_mysql0111!@#"
Mysql_host = "8.219.42.196"
Mysql_port = 3306
Mysql_table = "git_repos_task"

# --- [Kafka配置] --
# KAFKA_server = "172.16.246.138:9092,172.16.246.140:9092,172.16.246.139:9092,172.16.246.136:9092"
KAFKA_server = "60.205.8.203:9094,59.110.150.176:9094,8.140.59.227:9094,8.141.93.245:9094"
# KAFKA_server = ""
KAFKA_username = "admin"
KAFKA_password = "Zx_kafka0722"
KAFKA_topic_changelog = "topic_github_changelog"  # Changelog
KAFKA_topic_Issues = "topic_github_issues"  # Issues
KAFKA_topic_discussions = "topic_github_discussions"  # discussions
KAFKA_batch_size = 10
