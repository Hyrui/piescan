import time
import urllib3
import requests
import traceback
from loguru import logger
from urllib3.exceptions import InsecureRequestWarning
from func_timeout import func_timeout, FunctionTimedOut
from lxml import etree

from cli_mysql import Mysql_Cli
from config import main_config
from kafka_dt import KafkaManager

# 配置日志记录器
urllib3.disable_warnings(InsecureRequestWarning)


def timeout_requests(url):
    headers = {
        "user-agent": "Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Mobile Safari/537.36"
    }
    response = requests.get(url, headers=headers, timeout=10, verify=False)
    return response


def my_requests(url):
    """ 对数据进行采集
    """
    for i in range(1, 4):
        try:
            logger.info(f"Start requests url: {url}")
            try:
                resp = func_timeout(30, timeout_requests, args=(url,))
                return resp
            except FunctionTimedOut:
                logger.error("requests采集执行超时！")
                return None, None

        except Exception as e:
            print("=" * 10)
            logger.error(f"Requests Error:{e}, | URL: {url}")
            print("=" * 10)


def parses_list(response):
    html = etree.HTML(response.text)
    all_detail_href_base = html.xpath(
        "//a[@class='markdown-title discussion-Link--secondary js-navigation-open Link--primary Link f4 wb-break-word d-inline-block v-align-middle mr-1 tmp-mr-1']/@href")
    all_detail_href = ["https://github.com" + i for i in all_detail_href_base]
    next_page = "https://github.com" + "".join(html.xpath("//a[text()='Next']/@href"))

    return all_detail_href, next_page


def parses_detail(url, response):
    html = etree.HTML(response.text)
    item = {
        "id": "".join(html.xpath('//meta[@name="octolytics-dimension-repository_id"]/@content')),
        "url": url,
        "desc": "",
        "full_name": "".join(html.xpath('//meta[@name="octolytics-dimension-repository_nwo"]/@content')),
        "user_id": "".join(html.xpath('//meta[@name="octolytics-dimension-user_id"]/@content')),
        "user_name": "".join(html.xpath('//meta[@name="octolytics-dimension-user_login"]/@content')),
    }
    item["user_url"] = "https://github.com/" + item["user_id"]
    item["gt"] = time.time()

    # 新增字段
    cont = "\n".join(
        html.xpath("//div[@class='discussion js-discussion js-socket-channel js-updatable-content']//text()"))
    item["disc_title"] = "".join(html.xpath("//h1/span[@class='js-issue-title markdown-title']/text()")).strip("\n ")
    item["disc_cont"] = cont.replace("\n\n", "").replace("  ", "").replace("\n\n", "\n").replace("\n\n", "\n")
    item["disc_cate"] = "".join(html.xpath(
        "//a[@class='Link--onHover d-flex flex-row flex-items-center text-small color-fg-default text-bold no-underline']/text()")).strip(
        "\n ")
    item["disc_part"] = "".join(html.xpath(
        "//a[@class='Link--onHover d-flex flex-row flex-items-center text-small color-fg-default text-bold no-underline']/text()")).strip(
        "\n ")

    return item


def save_to_kafka(result_data):
    """存储"""
    logger.info(f"数据存储")
    kafka_gitinfo = KafkaManager(servers=main_config.KAFKA_server,
                                 user=main_config.KAFKA_username,
                                 password=main_config.KAFKA_password,
                                 topic=main_config.KAFKA_topic_discussions)
    kafka_gitinfo.write_data(main_config.KAFKA_topic_discussions, result_data)


def start(url):
    url = url + "discussions/" if url.endswith("/") else url + "/discussions/"
    resp = my_requests(url)
    all_list, next_page = parses_list(resp)
    for detail_href in all_list:
        detail_resp = my_requests(detail_href)
        items = parses_detail(url, detail_resp)
        print(items)
        save_to_kafka(items)

    if next_page:
        logger.info(f"执行翻页采集：{next_page}")
        start(next_page)


def get_task(mysql):
    params = {}
    SQL = f"SELECT * FROM {main_config.Mysql_table};"
    rows = mysql.select_all(SQL, params)
    return rows


def main():
    """主服务循环"""
    mysql = Mysql_Cli(
        database=main_config.Mysql_database,
        user=main_config.Mysql_user,
        password=main_config.Mysql_pwd,
        address=main_config.Mysql_host,
        port=main_config.Mysql_port,
        connect_timeout=10,
        read_timeout=30
    )

    logger.info("启动 MySQL 读取服务")
    while True:
        rows = get_task(mysql)
        for row in rows:
            try:
                url = row.get("url", "")
                start(url)
            except:
                traceback.print_exc()


if __name__ == '__main__':
    # main()
    start("https://github.com/NanmiCoder/MediaCrawler/")
