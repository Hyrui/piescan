import time
import traceback

import urllib3
import requests
from loguru import logger
from lxml import etree
from urllib3.exceptions import InsecureRequestWarning
from dateutil.parser import parse as dateutil_parser

from cli_mysql import Mysql_Cli
from config import main_config
from kafka_dt import KafkaManager

# 配置日志记录器
urllib3.disable_warnings(InsecureRequestWarning)


def save_to_kafka(result_data):
    """存储"""
    logger.info(f"数据存储")
    kafka_gitinfo = KafkaManager(servers=main_config.KAFKA_server,
                                 user=main_config.KAFKA_username,
                                 password=main_config.KAFKA_password,
                                 topic=main_config.KAFKA_topic_changelog)
    kafka_gitinfo.write_data(main_config.KAFKA_topic_changelog, result_data)


def str_format(str_):
    status = True
    while status:
        if "  " not in str_ and "\n \n" not in str_ and "\n\n" not in str_:
            return str_.strip("\n ")
        else:
            str_ = str_.replace("  ", " ")
            str_ = str_.replace("\n \n", " \n")
            str_ = str_.replace("\n\n", "\n")


def request_get(url, headers):
    for i in range(3):
        try:
            logger.info(f"请求链接： {url}")
            r = requests.get(url, headers=headers, timeout=10, verify=False)
            return r
        except:
            pass


def get_crawl_list(url):
    headers = {
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36"}
    r = request_get(url, headers)

    html = etree.HTML(r.text)
    tag_list = html.xpath('//div[@class="Box-row position-relative d-flex "]/div')
    crawl_url_list = []
    for tag in tag_list:
        tag_info = tag.xpath('.//ul[@class="list-style-none f6"]//text()')
        tag_info = [i.replace(" ", "").replace("\n", "") for i in tag_info]
        tag_info = [i for i in tag_info if i]

        tag_url = "".join(tag.xpath('.//h2/a/@href'))
        tag_url = "https://github.com" + tag_url

        if "Notes" in tag_info:
            crawl_url_list.append(tag_url)
    next_page = "https://github.com" + "".join(html.xpath("//a[text()='Next']/@href"))
    return crawl_url_list,next_page


def get_meta_content(etree_content, name, default=""):
    """解析meta标签内容"""
    content = etree_content.xpath(f".//meta[@name='{name}']/@content")
    return content[0] if content else default


def iso_to_timestamp(iso_str):
    """
    兼容所有 Python 版本的 ISO 时间转换
    """
    if not iso_str:
        return -1
    dt = dateutil_parser(iso_str)
    return time.mktime(dt.timetuple()) + dt.microsecond / 1e6


def crawl_tag_info(url):
    headers = {
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36"}
    r = request_get(url, headers)
    cont = etree.HTML(r.text)

    item = {
        "id": "".join(cont.xpath('//meta[@name="octolytics-dimension-repository_id"]/@content')),
        "url": url,
        "desc": "",
        "full_name": "".join(cont.xpath('//meta[@name="octolytics-dimension-repository_nwo"]/@content')),
        "user_id": "".join(cont.xpath('//meta[@name="octolytics-dimension-user_id"]/@content')),
        "user_name": "".join(cont.xpath('//meta[@name="octolytics-dimension-user_login"]/@content')),
    }
    item["user_url"] = "https://github.com/" + item["user_id"]
    item["gt"] = time.time()

    # 新增字段
    item["tag_name"] = "".join(cont.xpath("//h1[@class='tmp-mr-3 d-inline']/text()"))
    item["tag_author"] = "".join(cont.xpath("//a[@class='text-bold color-fg-muted']/text()"))
    item["tag_cont"] = " ".join(cont.xpath("//div[@class='markdown-body tmp-my-3']//text()"))
    return item


def start(url):
    url = url + "tags/" if url.endswith("/") else url + "/tags/"
    url_list, next_page = get_crawl_list(url)
    for url in url_list:
        item = crawl_tag_info(url)
        save_to_kafka(item)
    if next_page:
        logger.info(f"执行翻页采集：{next_page}")
        start(next_page)


def get_task(mysql):
    params = {}
    SQL = f"SELECT * FROM {main_config.Mysql_table};"
    rows = mysql.select_all(SQL, params)
    return rows


def main():
    """主服务循环"""
    mysql = Mysql_Cli(
        database=main_config.Mysql_database,
        user=main_config.Mysql_user,
        password=main_config.Mysql_pwd,
        address=main_config.Mysql_host,
        port=main_config.Mysql_port,
        connect_timeout=10,
        read_timeout=30
    )

    logger.info("启动 MySQL 读取服务")
    while True:
        rows = get_task(mysql)
        for row in rows:
            try:
                url = row.get("url", "")
                start(url)
            except:
                traceback.print_exc()


if __name__ == '__main__':
    main()
    # start("https://github.com/vllm-project/vllm/")
