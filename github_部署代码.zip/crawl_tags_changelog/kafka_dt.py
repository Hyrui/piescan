# -*- coding: utf-8 -*-
import logging
import time
import json
import traceback
from confluent_kafka import Producer, Consumer, KafkaError


class KafkaManager(object):
    def __init__(self, topic, servers=None, group=None, user=None, password=None):
        # 消费组
        if group:
            self.consumer_set = {
                'bootstrap.servers': servers,
                'group.id': group,
                'auto.offset.reset': 'earliest',
                'security.protocol': 'SASL_PLAINTEXT',
                'sasl.mechanisms': 'SCRAM-SHA-256',
                'sasl.username': user,
                'sasl.password': password,
            }
            self.consumer_set = {
                'bootstrap.servers': servers,
                'security.protocol': 'SASL_PLAINTEXT',
                'sasl.mechanisms': 'SCRAM-SHA-256',
                'sasl.username': user,
                'sasl.password': password,
                'group.id': group,
            }
            self.c = Consumer(self.consumer_set)
            self.c.subscribe([topic])
        else:
            self.producer_set = {
                'bootstrap.servers': servers,
                'security.protocol': 'SASL_PLAINTEXT',
                'sasl.mechanisms': 'SCRAM-SHA-256',
                'sasl.username': user,
                'sasl.password': password,
                'batch.size': 2097152,  # 批次的大小，单位是2Mb
                'message.max.bytes': 10485760,  # 设置为适当的值，单位是10Mb
                'compression.type': 'gzip',  # 消息压缩, 或者 'snappy' 或 'lz4'
                'compression.level': 9,  # 设置压缩级别，范围是 1 到 9
                'linger.ms': 1000,  # 发送消息之前等待更多消息加入批次,单位是毫秒
                'batch.num.messages': 1000,  # 每批消息的数量

                # 超时
                "session.timeout.ms": 300000,  # 会话超时（5分钟）
                "heartbeat.interval.ms": 60000,  # 心跳间隔（1分钟）
                # "max.poll.interval.ms" : 1200000,  # 最大处理时间（20分钟，读完数据后的处理时间）
                "request.timeout.ms": 305000,  # 请求超时（略大于 session.timeout.ms）
            }
            self.pro = Producer(**self.producer_set)

    def write_data(self, topic, result_data):
        """生产消息到Kafka"""
        try:
            def delivery_report(err, msg):
                """回调函数 异步"""
                if err is not None:
                    logging.error(f'Message delivery failed: {err}')
                # else:
                #     logging.info(f'Save OK: {msg.topic()}')

            if isinstance(result_data, list):
                for each_res in result_data:
                    each_str = each_res if isinstance(each_res, str) else json.dumps(each_res, ensure_ascii=False)
                    self.pro.produce(topic, each_str, callback=delivery_report)
                self.pro.flush()
            elif isinstance(result_data, str):
                self.pro.produce(topic, result_data, callback=delivery_report)
                self.pro.flush()
            elif isinstance(result_data, dict):
                data_str = json.dumps(result_data, ensure_ascii=False)
                self.pro.produce(topic, data_str, callback=delivery_report)
                self.pro.flush()

            else:
                print(f"Result format error. Result: {result_data}, Type: {type(result_data)}")

        except Exception as e:
            print(f"produce error: {e}")
            traceback.print_exc()
            self.pro = Producer(**self.producer_set)

    def read_data(self, batch_size=10, timeout=6):
        data_list = []
        for _ in range(batch_size):
            try:
                msg_batch = self.c.poll(timeout=0)
            except KeyboardInterrupt as e:
                return data_list
            if not msg_batch:
                continue
            data_list.append(msg_batch.value().decode("utf-8"))
        return data_list

    def stop(self):
        pass
