"""
MySQL客户端封装
"""

import logging
from pymysql import connect, cursors
from pymysql.err import MySQLError, OperationalError


class Mysql_Cli:
    def __init__(
            self,
            database: str,
            user: str,
            password: str,
            address: str = "localhost",
            port: int = 3306,
            connect_timeout: int = 10,
            read_timeout: int = 30,
            pool_size: int = 5
    ):
        self.config = {
            'host'           : address,
            'port'           : port,
            'user'           : user,
            'password'       : password,
            'db'             : database,
            'charset'        : 'utf8mb4',
            'cursorclass'    : cursors.DictCursor,
            'connect_timeout': connect_timeout,
            'read_timeout'   : read_timeout
        }
        self.pool_size = pool_size
        self.connections = []
        self._init_pool()
    
    def _init_pool(self):
        """初始化连接池"""
        for _ in range(self.pool_size):
            self.connections.append(self._create_connection())
    
    def _create_connection(self):
        """创建新连接"""
        try:
            return connect(**self.config)
        except OperationalError as e:
            logging.error(f"MySQL连接失败: {str(e)}")
            raise
    
    def get_connection(self):
        """从池中获取可用连接"""
        for conn in self.connections:
            try:
                conn.ping(reconnect=True)
                return conn
            except OperationalError:
                self.connections.remove(conn)
                new_conn = self._create_connection()
                self.connections.append(new_conn)
                return new_conn
        raise MySQLError("No available MySQL connections")
    
    def select_one(self, sql: str):
        """查询单行数据"""
        conn = None
        cursor = None
        try:
            conn = self.get_connection()
            with conn.cursor() as cursor:
                cursor.execute(sql)
                return cursor.fetchall()
        except OperationalError as e:
            logging.error(f"MySQL查询失败: {str(e)}")
            raise MySQLError(str(e))
        finally:
            if cursor:
                cursor.close()
                
    def select_all(self, sql: str, params):
        """查询多行数据"""
        conn = None
        cursor = None
        try:
            conn = self.get_connection()
            with conn.cursor() as cursor:
                cursor.execute(sql, params)
                return cursor.fetchall()
        except OperationalError as e:
            logging.error(f"MySQL查询失败: {str(e)}")
            raise MySQLError(str(e))
        finally:
            if cursor:
                cursor.close()
    
    def execute(self, sql: str, params):
        """执行单条SQL"""
        conn = None
        cursor = None
        try:
            conn = self.get_connection()
            with conn.cursor() as cursor:
                affected = cursor.execute(sql, params)
                conn.commit()
                return affected
        except OperationalError as e:
            if conn:
                conn.rollback()
            logging.error(f"MySQL执行失败: {str(e)}\nSQL: {sql}")
            raise MySQLError(str(e))
        finally:
            if cursor:
                cursor.close()
    
    # def execute_many(self, sql: str, params):
    #     """批量执行SQL"""
    #     conn = None
    #     cursor = None
    #     try:
    #         conn = self.get_connection()
    #         with conn.cursor() as cursor:
    #             affected = cursor.executemany(sql, params)
    #             conn.commit()
    #             return affected
    #     except OperationalError as e:
    #         if conn:
    #             conn.rollback()
    #         logging.error(f"MySQL批量执行失败: {str(e)}\nSQL: {sql}")
    #         raise MySQLError(str(e))
    #     finally:
    #         if cursor:
    #             cursor.close()
    
    def execute_many(self, sql: str, params, unique_key: str = 'url'):
        """通用的批量插入/更新方法"""
        conn = None
        cursor = None
        try:
            conn = self.get_connection()
            with conn.cursor() as cursor:
                # 解析原始SQL获取表名和字段
                if "INSERT INTO" in sql.upper():
                    # 提取表名和字段部分
                    parts = sql.upper().split("INSERT INTO")[1].split("VALUES")[0].strip()
                    table_name = parts.split()[0].strip('`').lower()

                    # (crawl_count, crawled, last_crawl_time, old_ut, pt, rele_commit_id, repo_commit_id, taskid, url, ut, tasklevel)
                    complete_sql = f"""
                    INSERT INTO {table_name}
                    (crawl_count, crawled, last_crawl_time, old_ut, pt, rele_commit_id, repo_commit_id, taskid, tasklevel, url, ut)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    ON DUPLICATE KEY UPDATE
                    crawled = VALUES(crawled),
                    pt = VALUES(pt),
                    crawl_count = VALUES(crawl_count),
                    old_ut = VALUES(old_ut),
                    ut = VALUES(ut),
                    last_crawl_time = VALUES(last_crawl_time),
                    repo_commit_id = VALUES(repo_commit_id),
                    rele_commit_id = VALUES(rele_commit_id),
                    tasklevel = VALUES(tasklevel)
                    """
                    affected = cursor.executemany(complete_sql, params)
                    conn.commit()
                    return affected
                else:
                    # 如果不是INSERT语句，直接执行
                    affected = cursor.executemany(sql, params)
                    conn.commit()
                    return affected
        
        except OperationalError as e:
            if conn:
                conn.rollback()
            logging.error(f"MySQL批量执行失败: {str(e)}")
            raise MySQLError(str(e))
        finally:
            if cursor:
                cursor.close()
    
    def ping(self, reconnect: bool = True):
        """检查连接活性"""
        for conn in self.connections:
            try:
                conn.ping(reconnect)
            except OperationalError:
                self.connections.remove(conn)
                self.connections.append(self._create_connection())
    
    def close(self):
        """关闭所有连接"""
        for conn in self.connections:
            try:
                conn.close()
            except OperationalError:
                pass
        self.connections = []
        logging.info("MySQL连接池已关闭")


# 测试用例
if __name__ == '__main__':
    # 示例配置
    test_config = {
        'database': 'test_db',
        'user'    : 'root',
        'password': 'password',
        'address' : 'localhost',
        'port'    : 3306
    }
    
    # 初始化客户端
    mysql = Mysql_Cli(**test_config)
    
    try:
        # 测试查询
        rows = mysql.select_all("SELECT * FROM users LIMIT 5")
        print(f"查询结果: {rows}")
        
        # 测试插入
        affected = mysql.execute(
            "INSERT INTO users (name, age) VALUES (%s, %s)",
            ("张三", 25)
        )
        print(f"插入影响行数: {affected}")
        
        # 测试批量操作
        batch_data = [("李四", 30), ("王五", 28)]
        affected = mysql.execute_many(
            "INSERT INTO users (name, age) VALUES (%s, %s)",
            batch_data
        )
        print(f"批量插入影响行数: {affected}")
    
    finally:
        mysql.close()